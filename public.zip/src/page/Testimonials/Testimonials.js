import React from "react";

const Testimonials = () => {
  return <></>;
};

export default Testimonials;
