export const CURRENCY = "$";
export const TIMEZONE = "America/Los_Angeles";
export const IMG = "https://admin.wrappedinmusic.com";
// ? ====== BASE URL ======
//export const URL = "https://webarttechnology.co.in/admin";
export const CONTACTUS = "https://admin.wrappedinmusic.com/backend";
export const URL = "https://admin.wrappedinmusic.com/backend/admin";
//export const URL = "http://admin.wrappedinmusic.mypickmyvote.com/api";

export const SIGNUP = `${URL}`;
export const CATAGORIES = `${URL}/category`;
export const SUBCATAGORIES = `${URL}/subcategory`;
export const SONGS = `${URL}/songs`;
export const SONGTEMPLETE = `${URL}/songtemplate`;
export const TEMPLETETYPE = `${URL}/templatetypes`;
export const GUIDE = `${URL}/guide`;
export const ORDER = `${URL}/getorder-list`;
export const GETSONGTEMPLETE = `${URL}/getsongtemplate`;
export const DELETETEMPLETE = `${URL}/deletetemplate`;
